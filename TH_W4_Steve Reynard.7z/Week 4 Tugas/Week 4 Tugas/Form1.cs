﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Week4
{
    public partial class Form1 : Form
    {
        List<Team> Teamlist = new List<Team>();
        string[] Pos = { "GK", "DF", "MF", "FW" };
        public Form1()
        {
            InitializeComponent();

            string[] presetteam = { "England", "England", "China" };
            string[] presetteam2 = { "Winchester", "Chelcia", "Shang Hai" };
            string[] presetteam3 = { "Winchester United", "Chelcia", "Xīwǒdeqiú" };

            string[] presetteam1player = { "Jack Smith", "Liam Thompson", "Emma Johnson", "Tom Brown", "Sophie Wilson", "Ryan Garcia", "Charlotte Davies", "Harry Robinson", "Grace Evans", "Connor White", "Olivia Martinez", "Joshua Taylor" };
            string[] presetteam1nomer = { "1", "2", "3", "6", "9", "10", "12", "13", "14", "15", "21", "22" };
            string[] presetteam1posisi = { "GK","DF","DF","DF","MF", "MF", "MF", "MF" ,"FW", "FW", "FW", "FW" };

            string[] presetteam2player = { "Harry Kane","Henry Bob", "Raheem Sterling", "Jordan Henderson", "Jack Grealish", "Mason Mount", "Ben Chilwell", "Kyle Walker", "Declan Rice", "Trent Alexander-Arnold", "Jadon Sancho", "Bukayo Saka" };
            string[] presetteam2nomer = { "1", "2", "5", "6", "9", "11", "12", "13", "17", "19", "21", "22" };
            string[] presetteam2posisi = { "GK", "DF", "DF", "DF", "DF", "MF", "MF", "MF", "FW", "FW", "FW", "FW" };

            string[] presetteam3player = { "Zhang Linpeng", "Wu Lei","Lin Lei", "Zheng Zhi", "Gao Lin", "Wang Shenchao", "Zhang Xizhe", "Wu Xi", "Yang Xu", "Hao Junmin", "Yu Dabao", "Liu Yang" };
            string[] presetteam3nomer = { "1", "2", "4", "5", "7", "10", "13", "14", "15", "16", "21", "25" };
            string[] presetteam3posisi = { "GK", "DF", "DF", "MF", "MF", "MF", "MF", "MF", "FW", "FW", "FW", "FW" };

            for (int j = 0; j < 3; j++)
            {
                Team team = new Team();
                team.teamCountry = presetteam[j];
                team.teamCity = presetteam2[j];
                team.teamName = presetteam3[j];
                List<Player> playerlist = new List<Player>();
                for (int i = 0; i < 12; i++)
                {
                    Player player = new Player();
                    if (j == 0)
                    {
                        player.playerName = presetteam1player[i];
                        player.playerNum = presetteam1nomer[i];
                        player.playerPos = presetteam1posisi[i];
                    }
                    else if (j == 1)
                    {
                        player.playerName = presetteam2player[i];
                        player.playerNum = presetteam2nomer[i];
                        player.playerPos = presetteam2posisi[i];
                    }
                    else
                    {
                        player.playerName = presetteam3player[i];
                        player.playerNum = presetteam3nomer[i];
                        player.playerPos = presetteam3posisi[i];
                    }
                    playerlist.Add(player);
                }
                team.Players = playerlist;
                Teamlist.Add(team);
            }

            for (int o = 0; o < Teamlist.Count; o++)
            {
                if (comboBox1.Items.Contains(Teamlist[o].teamCountry))
                {

                }
                else
                {
                    comboBox1.Items.Add(Teamlist[o].teamCountry);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            comboBox2.Text = "";
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string country = comboBox1.SelectedItem.ToString();
                if (Teamlist[i].teamCountry == country)
                {
                    comboBox2.Items.Add(Teamlist[i].teamName);
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = comboBox2.SelectedItem.ToString();
                if (Teamlist[i].teamName == team)
                {
                    for(int j = 0; j< Teamlist[i].Players.Count; j++)
                    {
                        string nama = Teamlist[i].Players[j].playerName;
                        string nom = Teamlist[i].Players[j].playerNum;
                        string pos = Teamlist[i].Players[j].playerPos;
                        listBox1.Items.Add("("+ nom + ") "+ nama + ","+ pos);
                    }
                    break;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool cek1 = false;

            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                for(int i = 0; i < Teamlist.Count; i++)
                {
                    if (Teamlist[i].teamName == textBox2.Text)
                    {
                        MessageBox.Show("Team already has been added");
                        break;
                        cek1 = true;
                    }
                }
                if (cek1)
                {

                }
                else
                {
                    Team team = new Team();
                    team.teamCountry = textBox1.Text;
                    team.teamName = textBox2.Text;
                    team.teamCity = textBox3.Text;
                    List<Player> playerlist = new List<Player>();
                    team.Players = playerlist;
                    Teamlist.Add(team);

                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Error, please fill the rest");
            }

            for (int o = 0; o < Teamlist.Count; o++)
            {
                if (comboBox1.Items.Contains(Teamlist[o].teamCountry))
                {

                }
                else
                {
                    comboBox1.Items.Add(Teamlist[o].teamCountry);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = comboBox2.SelectedItem.ToString();
                if (Teamlist[i].teamName == team && Teamlist[i].Players.Count > 11)
                {
                    Teamlist[i].Players.Remove(Teamlist[i].Players[listBox1.SelectedIndex]);
                    break;
                }
                else if (Teamlist[i].Players.Count <= 11)
                {
                    MessageBox.Show("Error, cannot be below 11 members");
                    break;
                }
                
            }

            listBox1.Items.Clear();
            for (int i = 0; i < Teamlist.Count; i++)
            {
                string team = comboBox2.SelectedItem.ToString();
                if (Teamlist[i].teamName == team)
                {
                    for (int j = 0; j < Teamlist[i].Players.Count; j++)
                    {
                        string nama = Teamlist[i].Players[j].playerName;
                        string nom = Teamlist[i].Players[j].playerNum;
                        string pos = Teamlist[i].Players[j].playerPos;
                        listBox1.Items.Add("(" + nom + ") " + nama + "," + pos);
                    }
                    break;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nama = textBox4.Text;
            string nom = textBox5.Text;
            string pos = Pos[comboBox3.SelectedIndex];

            if (nama != "" && nom != "" && comboBox3.SelectedIndex != -1)
            {
                if (comboBox1.SelectedIndex != -1 && comboBox2.SelectedIndex != -1)
                {
                    for (int i = 0; i < Teamlist.Count; i++)
                    {
                        string team = comboBox2.SelectedItem.ToString();
                        if (Teamlist[i].teamName == team)
                        {
                            bool cek2 = true;
                            for(int k = 0; k < Teamlist[i].Players.Count; k++)
                            {
                                if (Teamlist[i].Players[k].playerName == nama)
                                {
                                    cek2 = false;
                                } 
                            }
                            if (cek2)
                            {
                                Player player = new Player();
                                player.playerName = nama;
                                player.playerNum = nom;
                                player.playerPos = pos;
                                Teamlist[i].Players.Add(player);
                                listBox1.Items.Add("(" + nom + ") " + nama + "," + pos);
                            }
                            else
                            {
                                MessageBox.Show("player already exist");
                            }
                            break;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the team");
                }
                textBox4.Text = "";
                textBox5.Text = "";
                comboBox3.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Error, please fill the rest");
            }
        }

        
    }
}
